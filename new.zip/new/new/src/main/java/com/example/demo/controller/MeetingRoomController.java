package com.example.demo.controller;

import com.example.demo.model.MeetingRoom;
import com.example.demo.service.MeetingRoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;

@RestController
@RequestMapping("/api/meeting-rooms")
public class MeetingRoomController {

    @Autowired
    private MeetingRoomService meetingRoomService;

    @GetMapping
    public List<MeetingRoom> getAllMeetingRooms() {
        return meetingRoomService.getAllMeetingRooms();
    }

    @GetMapping("/{id}")
    public ResponseEntity<MeetingRoom> getMeetingRoomById(@PathVariable String id) {
        MeetingRoom meetingRoom = meetingRoomService.getMeetingRoomById(id);
        return meetingRoom != null ? ResponseEntity.ok(meetingRoom) : ResponseEntity.notFound().build();
    }

    @PostMapping
    public ResponseEntity<MeetingRoom> addMeetingRoom(@RequestBody MeetingRoom meetingRoom) {
        MeetingRoom createdRoom = meetingRoomService.addMeetingRoom(meetingRoom);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdRoom);
    }

    @PutMapping("/{id}")
    public ResponseEntity<MeetingRoom> updateMeetingRoom(@PathVariable String id, @RequestBody MeetingRoom meetingRoom) {
        MeetingRoom updatedRoom = meetingRoomService.updateMeetingRoom(id, meetingRoom);
        return updatedRoom != null ? ResponseEntity.ok(updatedRoom) : ResponseEntity.notFound().build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteMeetingRoom(@PathVariable String id) {
        meetingRoomService.deleteMeetingRoom(id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/initialize")
    public ResponseEntity<Void> initializeMeetingRooms() {
        MeetingRoom room1 = new MeetingRoom();
        room1.setName("Room 1");
        room1.setDescription("This is a meeting room.");
        room1.setCapacity(10);
        room1.setAvailable(true);

        MeetingRoom room2 = new MeetingRoom();
        room2.setName("Room 2");
        room2.setDescription("This is a meeting room.");
        room2.setCapacity(15);
        room2.setAvailable(true);

        MeetingRoom room3 = new MeetingRoom();
        room3.setName("Room 3");
        room3.setDescription("This is a meeting room.");
        room3.setCapacity(20);
        room3.setAvailable(true);

        MeetingRoom room4 = new MeetingRoom();
        room4.setName("Room 4");
        room4.setDescription("This is a meeting room.");
        room4.setCapacity(25);
        room4.setAvailable(true);

        List<MeetingRoom> meetingRooms = Arrays.asList(room1, room2, room3, room4);
        meetingRoomService.addAllMeetingRooms(meetingRooms);

        return ResponseEntity.status(HttpStatus.CREATED).build();
    }
}
