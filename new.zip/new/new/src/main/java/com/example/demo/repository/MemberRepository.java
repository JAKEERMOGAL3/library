package com.example.demo.repository;

import com.example.demo.model.Member;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface MemberRepository extends MongoRepository<Member, ObjectId> {
    Member findByUsername(String username);
    Member findByEmail(String email);

    // Add these methods
    boolean existsByUsername(String username);
    boolean existsByEmail(String email);
}
