package com.example.demo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

import com.example.demo.model.Book;

public interface BookRepository extends MongoRepository<Book, String> {

    // CRUD operations for ISBN
    Book findByISBN(String ISBN);
    void deleteByISBN(String ISBN);

    // CRUD operations for title
    List<Book> findByTitle(String title);
    void deleteByTitle(String title);

    // CRUD operations for author
    List<Book> findByAuthor(String author);
    void deleteByAuthor(String author);

    // CRUD operations for genre
    List<Book> findByGenre(String genre);
    void deleteByGenre(String genre);

    // Find books published after a specific year
    List<Book> findByYearOfPublicationGreaterThan(int year);

    // Find books published before a specific year
    List<Book> findByYearOfPublicationLessThan(int year);

    // Find books published between two specific years
    List<Book> findByYearOfPublicationBetween(int startYear, int endYear);

    // Find books by multiple criteria using a custom query
    @Query("{ 'author': ?0, 'genre': ?1 }")
    List<Book> findByAuthorAndGenre(String author, String genre);

    // Find books by multiple criteria using a custom query with pagination
    @Query("{ 'author': ?0, 'genre': ?1 }")
    List<Book> findByAuthorAndGenreWithPagination(String author, String genre, int page, int size);

    // You can add more custom queries as needed
}