package com.example.demo.service;

import com.example.demo.model.Checkout;
import com.example.demo.model.Item;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface CheckoutService {
    void saveCheckout(Checkout checkout);

    List<Item> getItemsForCheckout(String checkoutId);

    List<Item> getItemsForCheckout(String checkoutId, String itemType);

    Checkout getCheckoutByItemId(String itemId);
}