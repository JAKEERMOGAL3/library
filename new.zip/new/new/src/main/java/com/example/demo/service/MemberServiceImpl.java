package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.demo.model.Member;
import com.example.demo.repository.MemberRepository;
import org.bson.types.ObjectId;

import java.util.List;
import java.util.Optional;

@Service
public class MemberServiceImpl implements MemberService {

    @Autowired
    private MemberRepository memberRepository;

    @Override
    public List<Member> getAllMembers() {
        return memberRepository.findAll();
    }

    @Override
    public Member createMember(Member member) {
        return memberRepository.save(member);
    }

    @Override
    public Member getMemberById(ObjectId id) {
        Optional<Member> member = memberRepository.findById(id);
        return member.orElse(null);
    }

    @Override
    public Member updateMember(String memberId, Member updatedMember) {
        ObjectId objectId = new ObjectId(memberId);
        Optional<Member> memberOptional = memberRepository.findById(objectId);
        if (memberOptional.isPresent()) {
            Member existingMember = memberOptional.get();
            existingMember.setName(updatedMember.getName());
            existingMember.setAge(updatedMember.getAge());
            existingMember.setAddress(updatedMember.getAddress());
            existingMember.setUsername(updatedMember.getUsername());
            existingMember.setPassword(updatedMember.getPassword());
            return memberRepository.save(existingMember);
        } else {
            return null;
        }
    }

    @Override
    public void deleteMemberById(ObjectId id) {
        memberRepository.deleteById(id);
    }

    @Override
    public Member getMemberByUsername(String username) {
        return memberRepository.findByUsername(username);
    }

    @Override
    public Member getMemberByEmail(String email) {
        return memberRepository.findByEmail(email);
    }

    @Override
    public boolean isUsernameTaken(String username) {
        return memberRepository.existsByUsername(username);
    }

    @Override
    public boolean isEmailTaken(String email) {
        return memberRepository.existsByEmail(email);
    }
}
