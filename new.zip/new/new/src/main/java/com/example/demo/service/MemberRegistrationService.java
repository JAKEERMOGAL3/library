package com.example.demo.service;

import org.springframework.stereotype.Service;
import com.example.demo.model.Member;
import com.example.demo.repository.MemberRepository;

@Service
public class MemberRegistrationService {

    private final MemberRepository memberRepository;

    public MemberRegistrationService(MemberRepository memberRepository) {
        this.memberRepository = memberRepository;
    }

    public Member registerMember(Member member) {
        // Perform registration logic, validation, etc.

        // Save the member to the database
        return memberRepository.save(member);
    }

    // Additional methods if needed
}
