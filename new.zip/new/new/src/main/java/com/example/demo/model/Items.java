package com.example.demo.model;

public interface Items {
    String getId();
    void setId(String id);
    int getQuantity();
    void setQuantity(int quantity);
}