package com.example.demo.service;

import com.example.demo.model.Checkout;
import com.example.demo.model.Item;
import com.example.demo.repository.CheckoutRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CheckoutServiceImpl implements CheckoutService {

    @Autowired
    private CheckoutRepository checkoutRepository;

    @Override
    public void saveCheckout(Checkout checkout) {
        checkoutRepository.save(checkout);
    }

    @Override
    public List<Item> getItemsForCheckout(String checkoutId) {
        Checkout checkout = checkoutRepository.findById(checkoutId).orElse(null);
        if (checkout == null) {
            return new ArrayList<>();
        }
        return checkout.getItems();
    }

    @Override
    public List<Item> getItemsForCheckout(String checkoutId, String itemType) {
        Checkout checkout = checkoutRepository.findById(checkoutId).orElse(null);
        if (checkout == null) {
            return new ArrayList<>();
        }
        return checkout.getItems().stream()
                .filter(item -> item.getClass().getSimpleName().equalsIgnoreCase(itemType))
                .collect(Collectors.toList());
    }

    @Override
    public Checkout getCheckoutByItemId(String itemId) {
        List<Checkout> checkouts = checkoutRepository.findAll();
        for (Checkout checkout : checkouts) {
            for (Item item : checkout.getItems()) {
                if (item.getId().equals(itemId)) {
                    return checkout;
                }
            }
        }
        return null;
    }
    
    
}   