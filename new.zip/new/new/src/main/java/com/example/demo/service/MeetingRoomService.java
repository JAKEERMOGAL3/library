package com.example.demo.service;

import com.example.demo.model.Booking;
import com.example.demo.model.MeetingRoom;
import com.example.demo.repository.MeetingRoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

@Service
public class MeetingRoomService {

    @Autowired
    private MeetingRoomRepository meetingRoomRepository;

    public MeetingRoom findAvailableMeetingRoom() {
        return meetingRoomRepository.findByAvailableTrue();
    }

    public void markMeetingRoomAsBooked(MeetingRoom meetingRoom, Booking booking) {
        meetingRoom.setAvailable(false);
        meetingRoom.getBookings().add(booking);
        meetingRoomRepository.save(meetingRoom);
    }

    public List<Booking> findBookingsByMeetingRoomId(String id) {
        MeetingRoom meetingRoom = meetingRoomRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Meeting room not found"));
        return meetingRoom.getBookings();
    }

    public boolean isMeetingRoomAvailable(MeetingRoom meetingRoom, LocalDate date, LocalTime startTime, LocalTime endTime) {
        List<Booking> bookings = meetingRoom.getBookings();
        for (Booking booking : bookings) {
            if (date.isEqual(booking.getDate()) && (startTime.isBefore(booking.getEndTime()) && endTime.isAfter(booking.getStartTime()))) {
                return false;
            }
        }
        return true;
    }

    public MeetingRoom addMeetingRoom(MeetingRoom meetingRoom) {
        return meetingRoomRepository.save(meetingRoom);
    }

    public MeetingRoom updateMeetingRoom(String id, MeetingRoom meetingRoom) {
        MeetingRoom existingRoom = meetingRoomRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Meeting room not found"));
        existingRoom.setName(meetingRoom.getName());
        existingRoom.setDescription(meetingRoom.getDescription());
        existingRoom.setCapacity(meetingRoom.getCapacity());
        existingRoom.setAvailable(meetingRoom.isAvailable());
        return meetingRoomRepository.save(existingRoom);
    }

    public void deleteMeetingRoom(String id) {
        meetingRoomRepository.deleteById(id);
    }

    public List<MeetingRoom> getAllMeetingRooms() {
        return meetingRoomRepository.findAll();
    }

    public MeetingRoom getMeetingRoomById(String id) {
        return meetingRoomRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Meeting room not found"));
    }

    public void bookMeetingRoom(String id, Booking booking) {
        MeetingRoom meetingRoom = getMeetingRoomById(id);
        if (isMeetingRoomAvailable(meetingRoom, booking.getDate(), booking.getStartTime(), booking.getEndTime())) {
            markMeetingRoomAsBooked(meetingRoom, booking);
        } else {
            throw new RuntimeException("Meeting room is not available at the specified date and time");
        }
    }

    public void cancelBooking(String meetingRoomId, String bookingId) {
        MeetingRoom meetingRoom = getMeetingRoomById(meetingRoomId);
        List<Booking> bookings = meetingRoom.getBookings();
        bookings.removeIf(booking -> booking.getId().equals(bookingId));
        meetingRoomRepository.save(meetingRoom);
    }

    public List<Booking> getBookingsByMeetingRoomId(String id) {
        MeetingRoom meetingRoom = meetingRoomRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Meeting room not found"));
        return meetingRoom.getBookings();
    }
    
 // Add the following method to the MeetingRoomService class

    public void addAllMeetingRooms(List<MeetingRoom> meetingRooms) {
        meetingRoomRepository.saveAll(meetingRooms);
    }

}
