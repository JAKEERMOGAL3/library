package com.example.demo.repository;

import com.example.demo.model.Computer;

import java.time.LocalDateTime;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

public interface ComputerRepository extends MongoRepository<Computer, String> {
    Computer findByName(String name);
    Computer findByAvailableTrue();

    // Check if a computer is booked for the specified time
    @Query("{ 'bookings': { '$elemMatch': { 'computer': ?0, 'dateTime': { '$gte': ?1, '$lt': ?2 } } } }")
    boolean existsByBookings_DateTimeBetween(Computer computer, LocalDateTime startDateTime, LocalDateTime endDateTime);
}