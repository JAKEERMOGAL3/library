package com.example.demo.model;


import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Checkout {

    private String id;
    private String checkoutId;
    private List<Item> items;

    public Checkout() {
        this.items = new ArrayList<>();
    }

    public Checkout(String checkoutId, List<Item> items) {
        this.checkoutId = checkoutId;
        this.items = items;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCheckoutId() {
        return checkoutId;
    }

    public void setCheckoutId(String checkoutId) {
        this.checkoutId = checkoutId;
    }

    public List<Item> getItems() {
        return items;
    }

    public void setItems(List<Item> items) {
        this.items = items;
    }

    public void addItem(Item item) {
        this.items.add(item);
    }

    public void removeItem(Item item) {
        this.items.remove(item);
    }

    public void removeItemById(String itemId) {
        this.items.removeIf(item -> item.getId().equals(itemId));
    }

    public int getTotalQuantity() {
        return this.items.stream().mapToInt(Item::getQuantity).sum();
    }

    //public double getTotalPrice() {
      //  return this.items.stream().mapToDouble(Item::getPrice).sum();
    //}

    public boolean isEmpty() {
        return this.items.isEmpty();
    }

    public void clearItems() {
        this.items.clear();
    }

    public Item getItemById(String itemId) {
        return this.items.stream().filter(item -> item.getId().equals(itemId)).findFirst().orElse(null);
    }

    public List<Item> getItemsByType(String itemType) {
        return this.items.stream().filter(item -> item.getItemType().equalsIgnoreCase(itemType)).collect(Collectors.toList());
    }
}