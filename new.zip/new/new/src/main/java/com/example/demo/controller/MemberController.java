package com.example.demo.controller;

//import com.example.demo.model.Checkout;
import com.example.demo.model.ForgotPasswordRequest;
//import com.example.demo.model.Item;
import com.example.demo.model.Member;
import com.example.demo.service.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

//import java.util.List;

@CrossOrigin(origins = "http://localhost:3000", methods = {RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST, RequestMethod.OPTIONS}, allowedHeaders = {"Content-Type", "Authorization", "X-Requested-With", "Accept", "Origin", "Access-Control-Request-Method", "Access-Control-Request-Headers"})
@RestController
@RequestMapping("/api/members")
public class MemberController {

    @Autowired
    private MemberService memberService;

    // Endpoint for handling forgot password requests
    @PostMapping("/forgotpassword")
    public ResponseEntity<?> forgotPassword(@RequestBody ForgotPasswordRequest forgotPasswordRequest) {
        try {
            Member member = memberService.getMemberByEmail(forgotPasswordRequest.getEmail());

            if (member != null) {
                // Add password recovery logic here
                return ResponseEntity.ok().build();
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Endpoint for registering a new member
    @Transactional
    @PostMapping("/register")
    public ResponseEntity<String> registerMember(@RequestBody Member registrationRequest) {
        try {
            if (!isValidRegistrationRequest(registrationRequest)) {
                return ResponseEntity.badRequest().body("Invalid registration request");
            }

            if (memberService.isUsernameTaken(registrationRequest.getUsername())) {
                return ResponseEntity.status(HttpStatus.CONFLICT).body("Username is already taken");
            }

            if (memberService.isEmailTaken(registrationRequest.getEmail())) {
                return ResponseEntity.status(HttpStatus.CONFLICT).body("Email is already taken");
            }

            memberService.createMember(registrationRequest);

            return ResponseEntity.ok().body("Registration successful");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Registration failed");
        }
    }

    // Helper method to validate registration request
    private boolean isValidRegistrationRequest(Member registrationRequest) {
        return registrationRequest != null &&
                registrationRequest.getName() != null &&
                registrationRequest.getAge() != 0 &&
                registrationRequest.getAddress() != null &&
                registrationRequest.getUsername() != null &&
                registrationRequest.getEmail() != null &&
                registrationRequest.getPassword() != null;
    }

    /*
    // Endpoint for handling checkout requests
    @PostMapping("/checkout")
    public ResponseEntity<?> checkoutItem(@RequestBody Checkout checkout) {
        try {
            if (checkout == null || checkout.getItems() == null || checkout.getItems().isEmpty()) {
                return ResponseEntity.badRequest().body("Invalid checkout request");
            }

            // Save checkout items to the database
            checkoutService.saveCheckout(checkout);

            return ResponseEntity.ok().body("Items checked out successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error checking out the items");
        }
    }
    */

    // Endpoint for getting items associated with a checkout
    /*@GetMapping("/checkout/{checkoutId}/items")
    public ResponseEntity<List<Item>> getItemsForCheckout(@PathVariable String checkoutId) {
        try {
            List<Item> items = checkoutService.getItemsForCheckout(checkoutId);

            if (items == null || items.isEmpty()) {
                return ResponseEntity.notFound().build();
            }

            return ResponseEntity.ok().body(items);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }*/
}
