package com.example.demo.repository;

import com.example.demo.model.Checkout;
import com.example.demo.model.Items;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CheckoutRepository extends MongoRepository<Checkout, String> {
    Page<Checkout> findByItems_Id(String itemId, Pageable pageable);
    Page<Checkout> findByItems_IdIn(List<Items> itemIds, Pageable pageable);
    Checkout findByItems_IdAndCheckoutId(String itemId, String checkoutId);
}