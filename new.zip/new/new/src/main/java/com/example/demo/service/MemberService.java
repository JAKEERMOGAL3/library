package com.example.demo.service;

import com.example.demo.model.Member;
import org.bson.types.ObjectId;

import java.util.List;

public interface MemberService {
    List<Member> getAllMembers();
    Member createMember(Member member);
    Member getMemberById(ObjectId id);
    Member updateMember(String memberId, Member updatedMember);
    void deleteMemberById(ObjectId id);
    Member getMemberByUsername(String username);
    Member getMemberByEmail(String email);
    boolean isUsernameTaken(String username);
    boolean isEmailTaken(String email);
}
