package com.example.demo.repository;

import com.example.demo.model.MeetingRoom;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface MeetingRoomRepository extends MongoRepository<MeetingRoom, String> {
    MeetingRoom findByName(String name);

	MeetingRoom findByAvailableTrue();
}