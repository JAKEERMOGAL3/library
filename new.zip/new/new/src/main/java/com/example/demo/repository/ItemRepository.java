package com.example.demo.repository;

import com.example.demo.model.Item;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface ItemRepository extends MongoRepository<Item, String> {
        @Query("{ 'name' : ?0, 'customFieldName' : ?1 }")
        Item findByNameAndCustomFieldName(String name, String customFieldName);
    }

