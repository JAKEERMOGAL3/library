package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.demo.model.Checkout;
import com.example.demo.model.Item;
import com.example.demo.service.CheckoutService;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

@CrossOrigin(origins = "http://localhost:3000", methods = {RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST, RequestMethod.OPTIONS}, allowedHeaders = {"Content-Type", "Authorization", "X-Requested-With", "Accept", "Origin", "Access-Control-Request-Method", "Access-Control-Request-Headers"})
@RestController
@RequestMapping("/api")
public class CheckoutController {

    @Autowired
    private CheckoutService checkoutService;

    @PostMapping("/checkout")
    public ResponseEntity<?> checkoutItem(@RequestBody Checkout checkout) {
        try {
            if (checkout == null || checkout.getItems() == null || checkout.getItems().isEmpty()) {
                return ResponseEntity.badRequest().body("Invalid checkout request");
            }

            // Save checkout items to the database
            checkoutService.saveCheckout(checkout);

            // Clear the cart after successful checkout
            //checkoutService.clearCart();

            return ResponseEntity.ok().body("Items checked out successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error checking out the items");
        }
    }

    @GetMapping("/checkout/{checkoutId}/items")
    public ResponseEntity<List<Item>> getItemsForCheckout(@PathVariable String checkoutId) {
        try {
            List<Item> items = checkoutService.getItemsForCheckout(checkoutId);

            if (items == null || items.isEmpty()) {
                return ResponseEntity.notFound().build();
            }

            return ResponseEntity.ok().body(items);
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    // Add this method to handle OPTIONS requests
    @RequestMapping(value = "/checkout", method = RequestMethod.OPTIONS)
    public ResponseEntity<Void> handleOptions() {
        HttpHeaders headers = new HttpHeaders();
        headers.setAllow(new HashSet<>(Arrays.asList(HttpMethod.POST, HttpMethod.GET)));
        return new ResponseEntity<Void>(headers, HttpStatus.OK);
    }

}