package com.example.demo.controller;

import com.example.demo.model.MeetingRoom;
import com.example.demo.repository.MeetingRoomRepository;
import com.example.demo.service.MeetingRoomService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:3000", methods = {RequestMethod.GET, RequestMethod.PUT, RequestMethod.POST, RequestMethod.OPTIONS}, allowedHeaders = {"Content-Type", "Authorization", "X-Requested-With", "Accept", "Origin", "Access-Control-Request-Method", "Access-Control-Request-Headers"})
@RequestMapping("/api/meeting-rooms")
public class MeetingRoomController {

    @Autowired
    private MeetingRoomService meetingRoomService;
    
    @Autowired
    private MeetingRoomRepository meetingRoomRepository;

    // Endpoint to fetch all meeting rooms
    @GetMapping("/checkavailbility")
    public List<MeetingRoom> getAllMeetingRooms() {
        return meetingRoomService.getAllMeetingRooms();
    }

    // Endpoint to add a new meeting room
    @PostMapping("/addroom")
    public ResponseEntity<MeetingRoom> addMeetingRoom(@RequestBody MeetingRoom meetingRoom) {
        MeetingRoom createdRoom = meetingRoomService.addMeetingRoom(meetingRoom);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdRoom);
    }

    // Endpoint for single meeting room booking
    @PostMapping("/newroom")
    public ResponseEntity<String> createMeetingRoom(@RequestBody MeetingRoom meetingRoom) {
        LocalDate meetingDate = meetingRoom.getMeetingDate();
        LocalDateTime startTime = meetingRoom.getStartTime();
        LocalDateTime endTime = meetingRoom.getEndTime();

        // Check for overlapping meetings
        List<MeetingRoom> overlappingMeetings = meetingRoomRepository
                .findByMeetingDateAndStartTimeBetweenOrMeetingDateAndEndTimeBetween(
                        meetingDate,
                        startTime, endTime,
                        startTime, endTime
                );

        if (!overlappingMeetings.isEmpty()) {
            return new ResponseEntity<>("Meeting already booked for the specified time range.", HttpStatus.BAD_REQUEST);
        }

        // If no overlapping meetings, proceed to save the new meeting
        meetingRoomRepository.save(meetingRoom);
        return new ResponseEntity<>("Meeting room created successfully.", HttpStatus.CREATED);
    }
    
    // Endpoint for scheduling multiple meetings at a time
    @PostMapping("/batch")
    public String addMultipleMeeting(@RequestBody List<MeetingRoom> rooms) {
    	try {
    	meetingRoomService.createMeetingRooms(rooms);
		return "Meeting Added Successfully";
    	}catch(Exception e) {
    		throw new RuntimeException(e.getMessage());
    	}
    	
    }
}
