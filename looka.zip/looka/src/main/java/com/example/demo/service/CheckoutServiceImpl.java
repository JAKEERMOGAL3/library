package com.example.demo.service;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.example.demo.model.Checkout;
import com.example.demo.model.Item;
import com.example.demo.repository.CheckoutRepository;

@Service
public class CheckoutServiceImpl {

    @Autowired
    private CheckoutRepository checkoutRepository;

    public List<Item> getItemsByCheckoutId(String checkoutId) {
        Checkout checkout = checkoutRepository.findById(checkoutId).orElse(null);
        if (checkout == null) {
            return new ArrayList<>();
        }
        List<Checkout.Item> checkoutItems = checkout.getItems();
        List<Item> items = new ArrayList<>();
        for (Checkout.Item checkoutItem : checkoutItems) {
            Item item = new Item();
            item.setId(checkoutItem.getId());
            item.setName(checkoutItem.getName());
            item.setItemType(checkoutItem.getItemType());
            item.setQuantity(checkoutItem.getQuantity());
            items.add(item);
        }
        return items;
    }
    public String getItemType(Item item) {
        return item.getItemType();
    }
    

    public List<Item> getItemsByBookId(String bookId) {
        Pageable pageable = Pageable.unpaged();
        Page<Checkout> checkouts = checkoutRepository.findByBooks_Id(bookId, pageable);
        List<Item> items = new ArrayList<>();
        for (Checkout checkout : checkouts) {
            List<Checkout.Item> checkoutItems = checkout.getItems();
            for (Checkout.Item checkoutItem : checkoutItems) {
                Item item = new Item();
                item.setId(checkoutItem.getId());
                item.setName(checkoutItem.getName());
                item.setItemType(checkoutItem.getItemType());
                item.setQuantity(checkoutItem.getQuantity());
                items.add(item);
            }
        }
        return items;
    }

    public List<Item> getItemsByMeetingRoomId(String meetingRoomId) {
        Pageable pageable = Pageable.unpaged();
        Page<Checkout> checkouts = checkoutRepository.findByMeetingRooms_Id(meetingRoomId, pageable);
        List<Item> items = new ArrayList<>();
        for (Checkout checkout : checkouts) {
            List<Checkout.Item> checkoutItems = checkout.getItems();
            for (Checkout.Item checkoutItem : checkoutItems) {
                Item item = new Item();
                item.setId(checkoutItem.getId());
                item.setName(checkoutItem.getName());
                item.setItemType(checkoutItem.getItemType());
                item.setQuantity(checkoutItem.getQuantity());
                items.add(item);
            }
        }
        return items;
    }

    public List<Item> getItemsByComputerId(String computerId) {
        Pageable pageable = Pageable.unpaged();
        Page<Checkout> checkouts = checkoutRepository.findByComputers_Id(computerId, pageable);
        List<Item> items = new ArrayList<>();
        for (Checkout checkout : checkouts) {
            List<Checkout.Item> checkoutItems = checkout.getItems();
            for (Checkout.Item checkoutItem : checkoutItems) {
                Item item = new Item();
                item.setId(checkoutItem.getId());
                item.setName(checkoutItem.getName());
                item.setItemType(checkoutItem.getItemType());
                item.setQuantity(checkoutItem.getQuantity());
                items.add(item);
            }
        }
        return items;
    }
}