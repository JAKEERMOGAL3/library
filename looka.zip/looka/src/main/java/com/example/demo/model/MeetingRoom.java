package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Document(collection = "meeting_rooms")
public class MeetingRoom {

	@Id
	private Integer mettingId;
	private String name;
	private String description;
	private int capacity;
	private boolean available;
	private LocalDate meetingDate;

	private LocalDateTime startTime;

	private LocalDateTime endTime;

	private Long userId;

	private int quantity; // Added quantity field

	public Integer getMettingId() {
		return mettingId;
	}

	public void setMettingId(Integer mettingId) {
		this.mettingId = mettingId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public boolean isAvailable() {
		return available;
	}

	public void setAvailable(boolean available) {
		this.available = available;
	}

	public LocalDate getMeetingDate() {
		return meetingDate;
	}

	public void setMeetingDate(LocalDate meetingDate) {
		this.meetingDate = meetingDate;
	}

	public LocalDateTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalDateTime startTime) {
		this.startTime = startTime;
	}

	public LocalDateTime getEndTime() {
		return endTime;
	}

	public void setEndTime(LocalDateTime endTime) {
		this.endTime = endTime;
	}

	public Long getUserId() {
		return userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public MeetingRoom(Integer mettingId, String name, String description, int capacity, boolean available,
			LocalDate meetingDate, LocalDateTime startTime, LocalDateTime endTime, Long userId, int quantity) {
		super();
		this.mettingId = mettingId;
		this.name = name;
		this.description = description;
		this.capacity = capacity;
		this.available = available;
		this.meetingDate = meetingDate;
		this.startTime = startTime;
		this.endTime = endTime;
		this.userId = userId;
		this.quantity = quantity;
	}

}
