package com.example.demo.service;

import com.example.demo.model.Computer;
import com.example.demo.repository.ComputerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ComputerService {

    @Autowired
    private ComputerRepository computerRepository;

    // Get all computers
    public List<Computer> getAllComputers() {
        return computerRepository.findAll();
    }

    // Get computer by ID
    public Computer getComputerById(String id) {
        return computerRepository.findById(id).orElseThrow(() -> new RuntimeException("Computer not found"));
    }

    // Add a computer
    public Computer addComputer(Computer computer) {
        return computerRepository.save(computer);
    }

    // Update a computer
    public Computer updateComputer(String id, Computer computer) {
        Computer existingComputer = getComputerById(id);
        existingComputer.setName(computer.getName());
        existingComputer.setDescription(computer.getDescription());
       
        existingComputer.setAvailable(computer.isAvailable());
        return computerRepository.save(existingComputer);
    }

    // Delete a computer
    public void deleteComputer(String id) {
        computerRepository.deleteById(id);
    }

	public boolean checkComputerAvailability(String id, String date, String startTime, String endTime) {
		// TODO Auto-generated method stub
		return false;
	}
}
