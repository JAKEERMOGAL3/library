package com.example.demo.service;

import com.example.demo.model.MeetingRoom;
import com.example.demo.repository.MeetingRoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class MeetingRoomService {

    @Autowired
    private MeetingRoomRepository meetingRoomRepository;

    public MeetingRoom findAvailableMeetingRoom() {
        return meetingRoomRepository.findByAvailableTrue();
    }

    


   

    public MeetingRoom addMeetingRoom(MeetingRoom meetingRoom) {
        return meetingRoomRepository.save(meetingRoom);
    }

//    public MeetingRoom updateMeetingRoom(String id, MeetingRoom meetingRoom) {
//        MeetingRoom existingRoom = meetingRoomRepository.findById(id)
//                .orElseThrow(() -> new RuntimeException("Meeting room not found"));
//        existingRoom.setName(meetingRoom.getName());
//        existingRoom.setDescription(meetingRoom.getDescription());
//        existingRoom.setCapacity(meetingRoom.getCapacity());
//        existingRoom.setAvailable(meetingRoom.isAvailable());
//        return meetingRoomRepository.save(existingRoom);
//    }

    

    public List<MeetingRoom> getAllMeetingRooms() {
        return meetingRoomRepository.findAll();
    }

 
//    public void bookMeetingRoom(String id, Booking booking) {
//        MeetingRoom meetingRoom = getMeetingRoomById(id);
//        if (isMeetingRoomAvailable(meetingRoom, booking.getDate(), booking.getStartTime(), booking.getEndTime())) {
//            markMeetingRoomAsBooked(meetingRoom, booking);
//        } else {
//            throw new RuntimeException("Meeting room is not available at the specified date and time");
//        }
//    }

//    public void cancelBooking(String meetingRoomId, String bookingId) {
//        MeetingRoom meetingRoom = getMeetingRoomById(meetingRoomId);
//        List<Booking> bookings = meetingRoom.getBookings();
//        bookings.removeIf(booking -> booking.getId().equals(bookingId));
//        meetingRoomRepository.save(meetingRoom);
//    }

//    public List<Booking> getBookingsByMeetingRoomId(String id) {
//        MeetingRoom meetingRoom = meetingRoomRepository.findById(id)
//                .orElseThrow(() -> new RuntimeException("Meeting room not found"));
//        return meetingRoom.getBookings();
//    }
    
 // Add the following method to the MeetingRoomService class

    public void addAllMeetingRooms(List<MeetingRoom> meetingRooms) {
        meetingRoomRepository.saveAll(meetingRooms);
    }
    
    
   //post call for scheduling multiple meeting at a time
    public ResponseEntity<String> createMeetingRooms(List<MeetingRoom> meetingRooms) {
        // Check for overlapping meetings for each meeting room in the list
        for (MeetingRoom meetingRoom : meetingRooms) {
            LocalDate meetingDate = meetingRoom.getMeetingDate();
            LocalDateTime startTime = meetingRoom.getStartTime();
            LocalDateTime endTime = meetingRoom.getEndTime();

            List<MeetingRoom> overlappingMeetings = meetingRoomRepository
                    .findByMeetingDateAndStartTimeBetweenOrMeetingDateAndEndTimeBetween(
                            meetingDate,
                            startTime, endTime,
                            startTime, endTime
                    );

            if (!overlappingMeetings.isEmpty()) {
                return new ResponseEntity<>("Meeting already booked for the specified time range.", HttpStatus.BAD_REQUEST);
            }
        }

        // If no overlapping meetings, save all meeting rooms
        meetingRoomRepository.saveAll(meetingRooms);
        return new ResponseEntity<>("Meeting rooms created successfully.", HttpStatus.CREATED);
    }
    
    
    

}
