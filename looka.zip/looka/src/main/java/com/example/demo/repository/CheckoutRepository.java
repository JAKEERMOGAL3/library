package com.example.demo.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import com.example.demo.model.Checkout;

public interface CheckoutRepository extends MongoRepository<Checkout, String> {
    Page<Checkout> findByBooks_Id(String bookId, Pageable pageable);
    Page<Checkout> findByMeetingRooms_Id(String meetingRoomId, Pageable pageable);
    Page<Checkout> findByComputers_Id(String computerId, Pageable pageable);
    Page<Checkout> findByBooks_IdIn(List<String> bookIds, Pageable pageable);
    Page<Checkout> findByMeetingRooms_IdIn(List<String> meetingRoomIds, Pageable pageable);
    Page<Checkout> findByComputers_IdIn(List<String> computerIds, Pageable pageable);
    Checkout findByBooks_IdAndCheckoutId(String bookId, String checkoutId);
    Checkout findByMeetingRooms_IdAndCheckoutId(String meetingRoomId, String checkoutId);
    Checkout findByComputers_IdAndCheckoutId(String computerId, String checkoutId);
}