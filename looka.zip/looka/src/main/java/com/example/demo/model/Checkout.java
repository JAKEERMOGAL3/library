package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.ArrayList;
import java.util.List;

@Document(collection = "checkouts")
public class Checkout extends Item{

    @Id
    private String id;
    private List<Book> books;
    private List<Computer> computers;
    private List<MeetingRoom> meetingRooms;

    public Checkout() {
        // Initialize lists
        this.books = new ArrayList<>();
        this.computers = new ArrayList<>();
        this.meetingRooms = new ArrayList<>();
    }

    // Getters and setters
    public List<Book> getBooks() {
        return books;
    }
    

    public void setBooks(List<Book> books) {
        this.books = books;
    }

    public List<Computer> getComputers() {
        return computers;
    }

    public void setComputers(List<Computer> computers) {
        this.computers = computers;
    }

    public List<MeetingRoom> getMeetingRooms() {
        return meetingRooms;
    }

    public void setMeetingRooms(List<MeetingRoom> meetingRooms) {
        this.meetingRooms = meetingRooms;
    }

    
    public List<Item> getItems() {
        List<Item> allItems = new ArrayList<>();
        allItems.addAll(books);
        allItems.addAll(computers);
        allItems.addAll(meetingRooms);
        return allItems;
    }
    // Method to calculate total quantity of items in checkout
    public int getTotalQuantity() {
        return this.books.stream().mapToInt(Book::getQuantity).sum() +
               this.computers.stream().mapToInt(Computer::getQuantity).sum() +
               this.meetingRooms.stream().mapToInt(MeetingRoom::getQuantity).sum();
    }

    // Method to check if checkout is empty
    public boolean isEmpty() {
        return this.books.isEmpty() && this.computers.isEmpty() && this.meetingRooms.isEmpty();
    }

    // Method to clear all items from checkout
    public void clearItems() {
        this.books.clear();
        this.computers.clear();
        this.meetingRooms.clear();
    }

    // Method to get an item by its ID
    public Item getItemById(String itemId) {
        for (Book book : books) {
            if (book.getId().equals(itemId)) {
                return book;
            }
        }
        for (Computer computer : computers) {
            if (computer.getId().equals(itemId)) {
                return computer;
            }
        }
        for (MeetingRoom meetingRoom : meetingRooms) {
            if (meetingRoom.getId().equals(itemId)) {
                return meetingRoom;
            }
        }
        return null;
    }

    // Method to get items by type
    public List<Item> getItemsByType(String itemType) {
        List<Item> items = new ArrayList<>();
        if ("book".equals(itemType)) {
            items.addAll(books);
        } else if ("computer".equals(itemType)) {
            items.addAll(computers);
        } else if ("meetingRoom".equals(itemType)) {
            items.addAll(meetingRooms);
        }
        return items;
    }

    // Item class
    public static abstract class Item {
        private String id;
        private String name;
        private String description;
        private int quantity;

        // Getters and setters
        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public int getQuantity() {
            return quantity;
        }

        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }
    }

    // Book class
    public static class Book extends Item {
        private String author;

        // Constructors
        public Book() {}

        public Book(String id, String name, String description, String author, int quantity) {
            this.setId(id);
            this.setName(name);
            this.setDescription(description);
            this.author = author;
            this.setQuantity(quantity);
        }

        // Getter and setter for author
        public String getAuthor() {
            return author;
        }

        public void setAuthor(String author) {
            this.author = author;
        }
    }

    // Computer class
    public static class Computer extends Item {
        private String processor;
        private String ram;
        private String storage;

        // Constructors
        public Computer() {}

        public Computer(String id, String name, String description, String processor, String ram, String storage, int quantity) {
            this.setId(id);
            this.setName(name);
            this.setDescription(description);
            this.processor = processor;
            this.ram = ram;
            this.storage = storage;
            this.setQuantity(quantity);
        }

        // Getters and setters for processor, ram, and storage
        public String getProcessor() {
            return processor;
        }

        public void setProcessor(String processor) {
            this.processor = processor;
        }

        public String getRam() {
            return ram;
        }

        public void setRam(String ram) {
            this.ram = ram;
        }

        public String getStorage() {
            return storage;
        }

        public void setStorage(String storage) {
            this.storage = storage;
        }
    }

    // MeetingRoom class
    public static class MeetingRoom extends Item {
        private String capacity;

        // Constructors
        public MeetingRoom() {}

        public MeetingRoom(String id, String name, String description, String capacity, int quantity) {
            this.setId(id);
            this.setName(name);
            this.setDescription(description);
            this.capacity = capacity;
            this.setQuantity(quantity);
        }

        // Getter and setter for capacity
        public String getCapacity() {
            return capacity;
        }

        public void setCapacity(String capacity) {
            this.capacity = capacity;
        }
    }
}
