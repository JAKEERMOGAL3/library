package com.example.demo.service;

import com.example.demo.model.Checkout;
import com.example.demo.model.Item;

import java.util.List;
import java.util.Optional;

public interface CheckoutService {

    void saveCheckout(Checkout checkout);

    List<Item> getItemsForCheckout(String checkoutId);

    List<Item> getItemsForCheckout(String checkoutId, String itemType);

    Checkout getCheckoutByItemId(String itemId);

    // Update the return type of the getItemForCheckout method
    Optional<Item> getItemForCheckout(String checkoutId, String itemId);

    // Update the return type of the getItems method
    List<Item> getItems();
}
