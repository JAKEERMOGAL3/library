package com.example.demo.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "computers")
public class Computer {

    @Id
    private String id;
    private String name;
    private String description;
    private boolean available;
    private String date; // Add date field
    private String startTime; // Add startTime field
    private String endTime; // Add endTime field
    //private int quantity; // Added quantity field

    // Constructors, getters, and setters

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

   // public int getQuantity() {
     //   return quantity;
    //}

    //public void setQuantity(int quantity) {
      //  this.quantity = quantity;
    //}

    // Other methods
}
