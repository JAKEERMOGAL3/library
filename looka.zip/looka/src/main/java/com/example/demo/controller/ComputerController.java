package com.example.demo.controller;

import com.example.demo.model.Computer;
import com.example.demo.service.ComputerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/computers")
public class ComputerController {

    @Autowired
    private ComputerService computerService;

    @GetMapping
    public List<Computer> getAllComputers() {
        return computerService.getAllComputers();
    }

    @GetMapping("/{id}")
    public Computer getComputerById(@PathVariable String id) {
        return computerService.getComputerById(id);
    }

    @PostMapping
    public Computer addComputer(@RequestBody Computer computer) {
        return computerService.addComputer(computer);
    }

    @PutMapping("/{id}")
    public Computer updateComputer(@PathVariable String id, @RequestBody Computer computer) {
        return computerService.updateComputer(id, computer);
    }

    @DeleteMapping("/{id}")
    public void deleteComputer(@PathVariable String id) {
        computerService.deleteComputer(id);
    }
    
    @GetMapping("/{id}/availability")
    public boolean checkComputerAvailability(@PathVariable String id, @RequestParam String date, @RequestParam String startTime, @RequestParam String endTime) {
        return computerService.checkComputerAvailability(id, date, startTime, endTime);
    }


}
