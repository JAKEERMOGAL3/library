package com.example.demo.repository;

import com.example.demo.model.MeetingRoom;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

public interface MeetingRoomRepository extends MongoRepository<MeetingRoom, Integer> {
    MeetingRoom findByName(String name);
    
    List<MeetingRoom> findByMeetingDateAndStartTimeBetweenOrMeetingDateAndEndTimeBetween(
            LocalDate meetingDate,
            LocalDateTime startRange1, LocalDateTime endRange1,
            LocalDateTime startRange2, LocalDateTime endRange2
    );

	MeetingRoom findByAvailableTrue();
}