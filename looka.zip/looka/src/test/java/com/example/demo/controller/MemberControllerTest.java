package com.example.demo.controller;

import com.example.demo.service.MemberService;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;

 // Use SpringExtension instead of RunWith
@WebMvcTest(MemberController.class)
public class MemberControllerTest {

    @MockBean
    private MemberService memberService;

    @Test
    public void testGetAllMembers() throws Exception {
        // Your test logic here
    }

    @Test
    public void testCreateMember() throws Exception {
        // Your test logic here
    }

    @Test
    public void testGetMemberById() throws Exception {
        // Your test logic here
    }

    @Test
    public void testUpdateMember() throws Exception {
        // Your test logic here
    }

    @Test
    public void testDeleteMember() throws Exception {
        // Your test logic here
    }
}
